# Git Test for Chris Stein

1. Add (staging) = Checking the box next to the file
2. Commit added Files (with a message)
3. Push changes to github